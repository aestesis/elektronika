========================================================================
                MS Visual C++ CUSTOM APPWIZARD: VSTPlugIn GUI
========================================================================

This Custom App Wizard can be used to easily set up a new project for
the development of a VST PlugIn. The wizard creates code for a "do-nothing"
plugin, ready to compile/build and place in your VST PlugIn directory. But,
doing so wouldn't make much sense! Why use a plugin that does nothing? :)

The code produced uses VSTGUI Libraries in order to use a custom GUI and it 
is very similar to the "AGain" example in Steinbergs VST 2 SDK,
 the only difference is that this code does nothing att all. The plugin
created by the App Wizard has 1 parameter (fParam) and 1 programslot. You
can easily change the code to handle more parameters and programslots.

INSTALLATION
----------------------------------
�Close MS Visual C++
�Copy 'VSTPlugIn GUI AppWiz.awx' to: C:\Program Files\Microsoft Visual Studio\Common\MSDev98\Template


Please send any questions or suggestions to: support@borstnas.net

//Magnus Jonsson


========================================================================
CHANGELOG
========================================================================
2003-05-28		Added support for VSTGUI Library
2003-05-21		AppWiz updated to support Steinberg VST SDK 2.3
2003-05-21		Fixed the "fParam namebug"

KNOWN ISSUES:
========================================================================
�The created project is currently configured to:
"Use MFC in a shared DLL". Change this to: "Not using MFC"
for all configurations (project->settings) in order to
succesfully build the PlugIn-dll.

�The "amount" display doesn't respond to sliderchanges.

Fixes to these issues will be posted.


========================================================================
VSTPlugIn GUI AppWizard
(c) Borstnas Konsult HB