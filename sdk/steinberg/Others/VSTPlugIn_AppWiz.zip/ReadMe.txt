========================================================================
                MS Visual C++ CUSTOM APPWIZARD: VSTPlugIn
========================================================================

This Custom App Wizard can be used to easily set up a new project for
the development of a VST PlugIn. The wizard creates code for a "do-nothing"
plugin, ready to compile/build and place in your VST PlugIn directory. But,
doing so wouldn't make much sense! Why use a plugin that does nothing? :)

The code produced is very similar to the "AGain" example in Steinbergs
VST 2 SDK the only difference is that this code does nothing att all. The plugin
created by the App Wizard has 1 parameter (fParameter) and 1 programslot. You
can easily change the code to handle more parameters and programslots.

INSTALLATION
----------------------------------
�Close MS Visual C++
�Copy 'VSTPlugIn.awx' to: C:\Program Files\Microsoft Visual Studio\Common\MSDev98\Template


Please send any questions or suggestions to: support@borstnas.net

//Magnus Jonsson


========================================================================
CHANGELOG
========================================================================
2003-05-21		AppWiz updated to support Steinberg VST SDK 2.3
2003-05-21		Fixed the "fParam namebug"

