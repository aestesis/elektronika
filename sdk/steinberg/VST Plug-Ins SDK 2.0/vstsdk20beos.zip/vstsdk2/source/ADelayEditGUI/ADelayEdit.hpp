/*-----------------------------------------------------------------------------

� 1999, Steinberg Soft und Hardware GmbH, All Rights Reserved

-----------------------------------------------------------------------------*/
#ifndef __ADELAYEDIT_H
#define __ADELAYEDIT_H

#include "ADelay.hpp"
#include <string.h>

class ADelayEdit : public ADelay
{
public:
	ADelayEdit (audioMasterCallback audioMaster);
	~ADelayEdit ();

	virtual void setParameter (long index, float value);
};

#endif
