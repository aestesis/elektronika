/*-----------------------------------------------------------------------------

� 1999, Steinberg Soft und Hardware GmbH, All Rights Reserved

-----------------------------------------------------------------------------*/
#ifndef __ADEditor
#define __ADEditor


// include VSTGUI
#ifndef __vstgui__
#include "vstgui.h"
#endif


//-----------------------------------------------------------------------------
class ADEditor : public AEffGUIEditor, public CControlListener
{
public:
	ADEditor (AudioEffect *effect);
	virtual ~ADEditor ();

protected:
	virtual long open (void *ptr);
	virtual void close ();

	virtual void setParameter (long index, float value);
	virtual void valueChanged (CDrawContext* context, CControl* control);

private:
	// Controls
	CVerticalSlider *delayFader;
	CVerticalSlider *feedbackFader;
	CVerticalSlider *volumeFader;

	CParamDisplay *delayDisplay;
	CParamDisplay *feedbackDisplay;
	CParamDisplay *volumeDisplay;

	// Bitmaps
	CBitmap *hBackground;
	CBitmap *hFaderBody;
	CBitmap *hFaderHandle;
};

#endif
