// This is the main DLL file.

#pragma unmanaged
#include "..\\irrlicht\\include\\irrlicht.h"
#pragma comment (lib, "..\\release\\irrlicht.lib")
#pragma managed

#include "Irrlicht.NET.h"
#include "IVideoDriver.h"
#include "ISceneManager.h"
#include <vcclr.h> // for PtrToStringChars

namespace Irrlicht
{

IrrlichtDevice::IrrlichtDevice(Video::DriverType driverType)
: Device(0), ManagedVideoDriver(0), ManagedSceneManager(0)
{
	Device = irr::createDevice((irr::video::E_DRIVER_TYPE)driverType);
    
	if (!Device)
		throw new System::Exception(new System::String("Specified device could not be created."));

	ManagedVideoDriver = new Video::IVideoDriver(Device->getVideoDriver());
	ManagedSceneManager = new Scene::ISceneManager(Device->getSceneManager());
}

bool IrrlichtDevice::Run()
{
	return Device->run();
}

bool IrrlichtDevice::get_WindowActive()
{
	return Device->isWindowActive();
}

void IrrlichtDevice::CloseDevice()
{
	Device->closeDevice();
}

System::String* IrrlichtDevice::get_Version()
{
	return new System::String(Device->getVersion());
}

void IrrlichtDevice::set_ResizeAble(bool resize)
{
	return Device->setResizeAble(resize);
}

void IrrlichtDevice::set_WindowCaption(System::String* text)
{
	const wchar_t __pin* pinchars = PtrToStringChars(text); 
	Device->setWindowCaption(pinchars);
}

Video::IVideoDriver* IrrlichtDevice::get_VideoDriver()
{
	return ManagedVideoDriver;
}

Scene::ISceneManager* IrrlichtDevice::get_SceneManager()
{
	return ManagedSceneManager;
}

}