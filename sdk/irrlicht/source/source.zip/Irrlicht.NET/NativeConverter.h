#pragma once

#pragma unmanaged
#include "..\\irrlicht\\include\\rect.h"
#include "..\\irrlicht\\include\\position2d.h"
#pragma managed

#include "Rect.h"
#include "Position2D.h"
#include "Light.h"
#include "Color.h"
#include "Box3D.h"
#include "Matrix4.h"
#include "Material.h"
#include "Event.h"
#include "ViewFrustrum.h"

//   \\param {.*}\:
//   <param name="\1"/>

namespace irr
{
	// Class for converting native classes into .net ones and the other way round.
	// Could be optimized still a lot.
	class NativeConverter
	{
	public:
		
		inline static irr::core::rect<s32> getNativeRect(Irrlicht::Core::Rect r)
		{
			return core::rect<s32>(r.UpperLeftCorner.X, r.UpperLeftCorner.Y,
				r.LowerRightCorner.X, r.LowerRightCorner.Y);
		}

		inline static irr::core::position2d<s32> getNativePos(Irrlicht::Core::Position2D p)
		{
			return irr::core::position2d<s32>(p.X, p.Y);
		}

		inline static irr::video::SLight getNativeLight(Irrlicht::Video::Light light)
		{
			irr::video::SLight l = *((irr::video::SLight*)((void*)&light));
			return l;
		}

		inline static Irrlicht::Video::Light getNETLight(const irr::video::SLight& l)
		{
			Irrlicht::Video::Light light;
			light.AmbientColor = getNETColor(l.AmbientColor);
			light.CastShadows = l.CastShadows;
			light.DiffuseColor = getNETColor(l.DiffuseColor);
			light.Position.Set(l.Position.X, l.Position.Y, l.Position.Z);
			light.Radius = l.Radius;
			light.SpecularColor = getNETColor(l.SpecularColor);
			return light;
		}

		inline static irr::video::SColorf getNativeColorf(Irrlicht::Video::Colorf c)
		{
			return irr::video::SColorf(c.r, c.g, c.b, c.a);
		}

		inline static Irrlicht::Video::Colorf getNETColor(irr::video::SColorf c)
		{
			return Irrlicht::Video::Colorf(c.r, c.g, c.b, c.a);
		}

		inline static Irrlicht::Core::Box3D getNETBox(irr::core::aabbox3df b)
		{
			return Irrlicht::Core::Box3D(b.MinEdge.X, b.MinEdge.Y, b.MinEdge.Z,
				b.MaxEdge.X, b.MaxEdge.Y, b.MaxEdge.Z);
		}

		inline static irr::core::aabbox3df getNativeBox(Irrlicht::Core::Box3D b)
		{
			return irr::core::aabbox3df(b.MinEdge.X, b.MinEdge.Y, b.MinEdge.Z,
				b.MaxEdge.X, b.MaxEdge.Y, b.MaxEdge.Z);
		}

		inline static Irrlicht::Core::Matrix4 getNETMatrix(const irr::core::matrix4& mat)
		{
			Irrlicht::Core::Matrix4 nmat;
			for (int i=0; i<16; ++i)
				nmat.Members[i] = mat.M[i];

			return nmat;
		}

		inline static irr::core::matrix4 getNativeMatrix(Irrlicht::Core::Matrix4 mat)
		{
			irr::core::matrix4 nmat;
			for (int i=0; i<16; ++i)
				nmat.M[i] = mat.Members[i];

			return nmat;
		}

		inline static Irrlicht::Video::Material getNETMaterial(irr::video::SMaterial& material)
		{
			Irrlicht::Video::Material mat;
			mat.AmbientColor.color = material.AmbientColor.color;
			mat.DiffuseColor.color = material.DiffuseColor.color;
			mat.EmissiveColor.color = material.EmissiveColor.color;
			mat.Type = (Irrlicht::Video::MaterialType)material.MaterialType;
			mat.Texture1 = material.Texture1 ? new Irrlicht::Video::ITexture(material.Texture1) : 0;
			mat.Texture2 = material.Texture2 ? new Irrlicht::Video::ITexture(material.Texture2) : 0;

			for (int i=0; i<irr::video::EMF_MATERIAL_FLAG_COUNT; ++i)
				mat.Flags[i] = material.Flags[i];

			return mat;
		}

		inline static irr::video::SMaterial getNativeMaterial(Irrlicht::Video::Material& material)
		{
			irr::video::SMaterial mat;
			mat.AmbientColor.color = material.AmbientColor.color;
			mat.DiffuseColor.color = material.DiffuseColor.color;
			mat.EmissiveColor.color = material.EmissiveColor.color;
			mat.MaterialType = (irr::video::E_MATERIAL_TYPE)material.Type;
			mat.Texture1 = material.Texture1 ? material.Texture1->get_NativeTexture() : 0;
			mat.Texture2 = material.Texture2 ? material.Texture2->get_NativeTexture() : 0;

			for (int i=0; i<irr::video::EMF_MATERIAL_FLAG_COUNT; ++i)
				mat.Flags[i] = material.Flags[i];

			return mat;
		}

		inline static Irrlicht::Core::Vector3D getNETVector(irr::core::vector3df v)
		{
			return Irrlicht::Core::Vector3D(v.X, v.Y, v.Z);
		}

		inline static irr::core::vector3df getNativeVector(Irrlicht::Core::Vector3D v)
		{
			return irr::core::vector3df(v.X, v.Y, v.Z);
		}

		inline static irr::SEvent getNativeEvent(Irrlicht::Event event)
		{
			// TODO: implement
			return irr::SEvent();
		}

		inline static Irrlicht::Scene::ViewFrustrum getNETFrustrum(const irr::scene::SViewFrustrum& fr)
		{
			//TODO: implement
			return Irrlicht::Scene::ViewFrustrum();
		}

		inline static Irrlicht::Core::Dimension2Df getNETDim(irr::core::dimension2d<f32> dim)
		{
			return Irrlicht::Core::Dimension2Df(dim.Width, dim.Height);
		}

		inline static irr::core::dimension2d<f32> getNativeDim(Irrlicht::Core::Dimension2Df dim)
		{
			return irr::core::dimension2d<f32>(dim.Width, dim.Height);
		}

	};

}