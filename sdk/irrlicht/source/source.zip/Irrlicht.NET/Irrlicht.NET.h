// Copyright (C) 2002-2004 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in Irrlicht.h

#pragma once

#using <mscorlib.dll>
using namespace System;

#include "edrivertypes.h"

#pragma unmanaged
#include "..\\irrlicht\\include\\irrlicht.h"

#pragma managed

namespace Irrlicht
{
namespace Video
{
	public __gc class IVideoDriver;
}
namespace Scene
{
	public __gc class ISceneManager;
}
	/// <summary>
	/// The Irrlicht.NET device. This is the most important class of the Irrlicht Engine. You can access everything
	/// in the engine if you have a pointer to an instance of this class. 
	///
	/// This class has been ported directly from the native C++ Irrlicht Engine, so it may not 
	/// be 100% complete yet and the design may not be 100% .NET like.
	/// </summary>
	public __gc class IrrlichtDevice
	{
	public:

		IrrlichtDevice(Video::DriverType driverType);

		/// <summary>
		/// Runs the device. Returns false if device wants to be deleted.
		/// </summary>
		bool Run();

		/// <summary>
		/// Provides access to the video driver. This can be null, if the engine
		/// was not able to create the video driver you specified. For example if 
		/// you wanted D3D9, but it is not installed in the system.
		/// </summary>		
		__property Video::IVideoDriver* get_VideoDriver();

		/// <summary>
		/// Provides access to the scene manager.
		/// </summary>
		__property Scene::ISceneManager* get_SceneManager();

		/// \return Returns a pointer to the file system.
		//virtual io::IFileSystem* getFileSystem() = 0;

		/// \return Returns a pointer to the gui environment.
		//virtual gui::IGUIEnvironment* getGUIEnvironment() = 0;
		

		/// \return Returns a pointer to the mouse cursor control interface.
		//virtual gui::ICursorControl* getCursorControl() = 0;

		/// \return Returns a pointer to the logger.
		//virtual ILogger* getLogger() = 0;

		/// Gets a list with all video modes available. If you are confused 
		/// now, because you think you have to create an Irrlicht Device with a video
		/// mode before being able to get the video mode list, let me tell you that
		/// there is no need to start up an Irrlicht Device with DT_DIRECTX8, DT_OPENGL or
		/// DT_SOFTWARE: For this (and for lots of other reasons) the null device,
		/// DT_NULL exists.
		/// \return Returns a pointer to a list with all video modes supported
		/// by the gfx adapter.
		//virtual video::IVideoModeList* getVideoModeList() = 0;

		/// Returns the operation system opertator object. It provides methods for
		/// getting operation system specific informations and doing operation system
		/// specific operations. Like for example exchanging data with the clipboard
		/// or reading the operation system version.
		//virtual IOSOperator* getOSOperator() = 0;

		/// \return Returns a pointer to the ITimer object. With it the
		/// current Time can be received.
		//virtual ITimer* getTimer() = 0;

		/// <summary>
		/// Sets the caption of the window.
		/// <param name="text">New text of the window caption.</param>
		/// </summary>
		__property void set_WindowCaption(System::String* text);

		/// <summary>
		/// \return Returns true if window is active. If the window is inactive,
		/// nothing need to be drawn. So if you don't want to draw anything when
		/// the window is inactive, create your drawing loop this way:
		/// \code
		/// while(device->run())
		///		if (device->isWindowActive())
		///		{
		///			// draw everything here
		///		}
		/// \endcode
		/// </summary>
		__property bool get_WindowActive();

		/// <summary>
		/// Notifies the device that it should close itself.
		/// IrrlichtDevice::run() will always return false after closeDevice() was called.
		/// </summary>
		void CloseDevice();

		/// <summary>
		/// Returns the version of the engine. The returned string
		/// will look like this: "1.2.3" or this: "1.2". 
		/// </summary>
		__property System::String* get_Version();

		/// Sets a new event receiver to receive events.
		//virtual void setEventReceiver(IEventReceiver* receiver) = 0;

		/// <summary>
		/// Sets if the window should be resizeable in windowed mode. The default
		/// is false. This method only works in windowed mode.
		/// </summary>
		__property void set_ResizeAble(bool resize);

	private:

		irr::IrrlichtDevice* Device;
		Irrlicht::Video::IVideoDriver* ManagedVideoDriver;
		Irrlicht::Scene::ISceneManager* ManagedSceneManager;
	};

}