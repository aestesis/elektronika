// Copyright (C) 2002-2004 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in Irrlicht.h

#pragma once

#using <mscorlib.dll>
using namespace System;


namespace Irrlicht
{
namespace Scene
{

	/// <summary>
	/// Defines the view frustrum. Thats the space viewed by the camera.
	/// The view frustrum is enclosed by 6 planes. These six planes share
	/// four points. A bounding box around these four points is also stored in
	/// this structure.
	/// </summary>
	public __value class ViewFrustrum
	{
	};

}
}