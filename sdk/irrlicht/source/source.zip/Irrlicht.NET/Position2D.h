// Copyright (C) 2002-2004 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in Irrlicht.h

#pragma once

namespace Irrlicht
{
namespace Core
{

	/// <summary> 
	/// Specifies a two dimensional position. 
	/// </summary>
	public __value class Position2D
	{
		public:

			/// <summary> Constructs a position at (0,0) </summary>
			Position2D()
				: X(0), Y(0)
			{
			}
				
			/// <summary> Constructs a position. </summary>
			Position2D(int x, int y)
				: X(x), Y(y) 
			{
			}

			/// <summary>
			/// Compares the position to another position.
			/// </summary>
			bool Equals(Object* rhs) 
			{
				Position2D* c = dynamic_cast<Position2D *>(rhs);

				if(!c) 
					return false;

				return c->X == X && c->Y == Y;
			}

			int X, Y;
	};

} // end namespace Core
} // end namespace Irrlicht


