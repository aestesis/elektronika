#include "ISceneNode.h"
#include "NativeConverter.h"
#include <vcclr.h> // for PtrToStringChars

namespace Irrlicht
{
namespace Scene
{

	ISceneNode::ISceneNode(irr::scene::ISceneNode* realSceneNode)
		: SceneNode(realSceneNode)
	{
		SceneNode->grab();
	}

	ISceneNode::~ISceneNode()
	{
		SceneNode->drop();
	}

	void ISceneNode::Render()
	{
		SceneNode->render();
	}

	System::String* ISceneNode::get_Name()
	{
		return new System::String(SceneNode->getName());
	}

	void ISceneNode::set_Name(System::String* name)
	{
		const wchar_t __pin* pinchars = PtrToStringChars(name); 
		SceneNode->setName(pinchars);
	}

	Core::Box3D ISceneNode::get_BoundingBox()
	{
		return irr::NativeConverter::getNETBox(SceneNode->getBoundingBox());
	}

	Core::Box3D ISceneNode::get_TransformedBoundingBox()
	{
		return irr::NativeConverter::getNETBox(SceneNode->getTransformedBoundingBox());
	}

	Core::Matrix4 ISceneNode::get_AbsoluteTransformation()
	{
		return irr::NativeConverter::getNETMatrix(SceneNode->getAbsoluteTransformation());
	}

	Core::Matrix4 ISceneNode::get_RelativeTransformation()
	{
		return irr::NativeConverter::getNETMatrix(SceneNode->getRelativeTransformation());
	}

	bool ISceneNode::get_Visible()
	{
		return SceneNode->isVisible();
	}

	void ISceneNode::set_Visible(bool visible)
	{
		SceneNode->setVisible(visible);
	}

	int ISceneNode::get_ID()
	{
		return SceneNode->getID();
	}

	void ISceneNode::set_ID(int id)
	{
		SceneNode->setID(id);
	}

	void ISceneNode::AddChild(ISceneNode* child)
	{
		SceneNode->addChild(child ? child->SceneNode : 0);
	}

	bool ISceneNode::RemoveChild(ISceneNode* child)
	{
		return SceneNode->removeChild(child ? child->SceneNode : 0);
	}

	void ISceneNode::RemoveAll()
	{
		return SceneNode->removeAll();
	}

	void ISceneNode::Remove()
	{
		SceneNode->remove();
	}

	Video::Material ISceneNode::GetMaterial(int i)
	{
		return irr::NativeConverter::getNETMaterial(SceneNode->getMaterial(i));
	}

	void ISceneNode::SetMaterial(int i, Video::Material mat)
	{
		SceneNode->getMaterial(i) = irr::NativeConverter::getNativeMaterial(mat);
	}

	int ISceneNode::get_MaterialCount()
	{
		return SceneNode->getMaterialCount();
	}

	void ISceneNode::SetMaterialFlag(Video::MaterialFlag flag, bool newvalue)
	{
		SceneNode->setMaterialFlag((irr::video::E_MATERIAL_FLAG)flag, newvalue);
	}

	void ISceneNode::SetMaterialTexture(int textureLayer, Video::ITexture* texture)
	{
		SceneNode->setMaterialTexture(textureLayer, texture ? texture->get_NativeTexture() : 0);
	}

	void ISceneNode::SetMaterialType(Video::MaterialType newType)
	{
		SceneNode->setMaterialType((irr::video::E_MATERIAL_TYPE)newType);
	}
	
	Core::Vector3D ISceneNode::get_Scale()
	{
		return irr::NativeConverter::getNETVector(SceneNode->getScale());
	}

	void ISceneNode::set_Scale(Core::Vector3D scale)
	{
		SceneNode->setScale(irr::NativeConverter::getNativeVector(scale));
	}

	Core::Vector3D ISceneNode::get_Rotation()
	{
		return irr::NativeConverter::getNETVector(SceneNode->getRotation());
	}

	void ISceneNode::set_Rotation(Core::Vector3D v)
	{
		SceneNode->setRotation(irr::NativeConverter::getNativeVector(v));
	}

	Core::Vector3D ISceneNode::get_Position()
	{
		return irr::NativeConverter::getNETVector(SceneNode->getPosition());
	}

	void ISceneNode::set_Position(Core::Vector3D v)
	{
		SceneNode->setPosition(irr::NativeConverter::getNativeVector(v));
	}

	Core::Vector3D ISceneNode::get_AbsolutePosition()
	{
		return irr::NativeConverter::getNETVector(SceneNode->getAbsolutePosition());
	}

	void ISceneNode::set_AutomaticCulling(bool enabled)
	{
		SceneNode->setAutomaticCulling(enabled);
	}

	bool ISceneNode::get_AutomaticCulling()
	{
		return SceneNode->getAutomaticCulling();
	}

	void ISceneNode::set_DebugDataVisible(bool visible)
	{
		SceneNode->setDebugDataVisible(visible);
	}

	bool ISceneNode::get_DebugDataVisible()
	{
		return SceneNode->isDebugDataVisible();
	}

	void ISceneNode::SetParent(ISceneNode* newParent)
	{
		SceneNode->setParent(newParent ? newParent->SceneNode : 0);
	}

	void ISceneNode::UpdateAbsolutePosition()
	{
		SceneNode->updateAbsolutePosition();
	}

	irr::scene::ISceneNode* ISceneNode::get_NativeSceneNode()
	{
		return SceneNode;
	}

}
}
