#include "ISceneManager.h"
#include "NativeConverter.h"

namespace Irrlicht
{
namespace Scene
{

	ISceneManager::ISceneManager(irr::scene::ISceneManager* manager)
		: Manager(manager)
	{
		
	}

	IAnimatedMesh* ISceneManager::GetMesh(System::String* filename)
	{
		char* str = (char*)(void*)
			System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(filename);

		irr::scene::IAnimatedMesh* am = Manager->getMesh(str);
		if (!am)
			return 0;

		return new IAnimatedMesh(am);
	}

	ISceneNode* ISceneManager::AddTestSceneNode(float size, ISceneNode* parent, int id,
			 Core::Vector3D position, Core::Vector3D rotation, Core::Vector3D scale)
	{
		irr::scene::ISceneNode* node = 
			Manager->addTestSceneNode(size, parent ? parent->get_NativeSceneNode() : 0, id, 
			irr::NativeConverter::getNativeVector(position),
			irr::NativeConverter::getNativeVector(rotation),
			irr::NativeConverter::getNativeVector(scale));

		if (!node)
			return 0;

		return new ISceneNode(node);
	}

	ISceneNode* ISceneManager::AddTestSceneNode(float size, ISceneNode* parent, int id, Core::Vector3D position)
	{
		return AddTestSceneNode(size, parent, id, position,
			Irrlicht::Core::Vector3D(0,0,0), Irrlicht::Core::Vector3D(1,1,1));
	}

	ICameraSceneNode* ISceneManager::AddCameraSceneNodeFPS()
	{
		return AddCameraSceneNodeFPS(0, 100, 500, -1);
	}

	ICameraSceneNode* ISceneManager::AddCameraSceneNodeFPS(ISceneNode* parent,
		float rotateSpeed, float moveSpeed, int id)
	{
		irr::scene::ICameraSceneNode* node = 
			Manager->addCameraSceneNodeFPS(parent ? parent->get_NativeSceneNode() : 0,
			rotateSpeed, moveSpeed, id);
		if (!node)
			return 0;
		return new ICameraSceneNode(node);
	}

	void ISceneManager::DrawAll()
	{
		Manager->drawAll();
	}

	ISceneNode* ISceneManager::AddOctTreeSceneNode(IAnimatedMesh* mesh, ISceneNode* parent, int id)
	{
		return AddOctTreeSceneNode(mesh, parent, id, 128);
	}

	ISceneNode* ISceneManager::AddOctTreeSceneNode(IAnimatedMesh* mesh, ISceneNode* parent, 
			int id, int minimalPolysPerNode)
	{
		irr::scene::ISceneNode* node = Manager->addOctTreeSceneNode(
			mesh ? mesh->get_NativeAnimatedMesh() : 0, 
			parent ? parent->get_NativeSceneNode() : 0,
			id, minimalPolysPerNode);
		if (!node)
			return 0;
		return new ISceneNode(node);
	}

	ISceneNode* ISceneManager::AddOctTreeSceneNode(IMesh* mesh, ISceneNode* parent, int id)
	{
		return AddOctTreeSceneNode(mesh, parent, id, 128);
	}

	ISceneNode* ISceneManager::AddOctTreeSceneNode(IMesh* mesh, ISceneNode* parent, int id, int minimalPolysPerNode)
	{
		irr::scene::ISceneNode* node = Manager->addOctTreeSceneNode(
			mesh ? mesh->get_NativeMesh() : 0, 
			parent ? parent->get_NativeSceneNode() : 0,
			id, minimalPolysPerNode);
		if (!node)
			return 0;
		return new ISceneNode(node);
	}

	IAnimatedMeshSceneNode* ISceneManager::AddAnimatedMeshSceneNode(IAnimatedMesh* mesh, ISceneNode* parent, int id,
		Core::Vector3D position, Core::Vector3D rotation, Core::Vector3D scale)
	{
		irr::scene::IAnimatedMeshSceneNode* am = 
			Manager->addAnimatedMeshSceneNode(
				mesh ? mesh->get_NativeAnimatedMesh() : 0,
				parent ? parent->get_NativeSceneNode() : 0,
				id, 
				irr::NativeConverter::getNativeVector(position),
				irr::NativeConverter::getNativeVector(rotation),
				irr::NativeConverter::getNativeVector(scale));
		if (!am)
			return 0;

		return new IAnimatedMeshSceneNode(am);
	}

	IAnimatedMeshSceneNode* ISceneManager::AddAnimatedMeshSceneNode(IAnimatedMesh* mesh, ISceneNode* parent, int id)
	{
		return AddAnimatedMeshSceneNode(mesh, parent, id,
			Core::Vector3D(0,0,0), Core::Vector3D(0,0,0), Core::Vector3D(1,1,1));
	}

	ISceneNode* ISceneManager::AddMeshSceneNode(IMesh* mesh, ISceneNode* parent, int id)
	{
		return AddMeshSceneNode(mesh, parent, id, 
			Core::Vector3D(0,0,0), Core::Vector3D(0,0,0),
			Core::Vector3D(1,1,1));
	}

	ISceneNode* ISceneManager::AddMeshSceneNode(IMesh* mesh, ISceneNode* parent, int id,
			 Core::Vector3D position, Core::Vector3D rotation, Core::Vector3D scale)
	{
		irr::scene::ISceneNode* node =
			Manager->addMeshSceneNode(mesh ? mesh->get_NativeMesh() : 0,
			parent ? parent->get_NativeSceneNode() : 0,
			id, 
			irr::NativeConverter::getNativeVector(position),
			irr::NativeConverter::getNativeVector(rotation),
			irr::NativeConverter::getNativeVector(scale));
		if (!node)
			return 0;
		return new ISceneNode(node);
	}

	ISceneNode* ISceneManager::AddWaterSurfaceSceneNode(IMesh* mesh,
		float waveHeight, float waveSpeed, float waveLenght, 
		ISceneNode* parent, int id)
	{
		irr::scene::ISceneNode* node = 
			Manager->addWaterSurfaceSceneNode(
			mesh? mesh->get_NativeMesh() : 0,
			waveHeight, waveSpeed, waveLenght, 
			parent ? parent->get_NativeSceneNode() : 0,
			id);
		if (!node)
			return 0;
		return new ISceneNode(node);
	}

	ICameraSceneNode* ISceneManager::AddCameraSceneNode(ISceneNode* parent,
			 Core::Vector3D position, Core::Vector3D lookat, int id)
	{
		irr::scene::ICameraSceneNode* cam =
			Manager->addCameraSceneNode(
			parent ? parent->get_NativeSceneNode() : 0,
			irr::NativeConverter::getNativeVector(position),
			irr::NativeConverter::getNativeVector(lookat), id);
		if (!cam)
			return 0;
		return new ICameraSceneNode(cam);
	}

	ICameraSceneNode* ISceneManager::AddCameraSceneNodeMaya(ISceneNode* parent,
			float rotateSpeed, float zoomSpeed, float translationSpeed, int id)
	{
		irr::scene::ICameraSceneNode* cam =
			Manager->addCameraSceneNodeMaya(
			parent ? parent->get_NativeSceneNode() : 0,
			rotateSpeed, zoomSpeed, translationSpeed, id);
		if (!cam)
			return 0;
		return new ICameraSceneNode(cam);
	}

	ILightSceneNode* ISceneManager::AddLightSceneNode(ISceneNode* parent,
			Core::Vector3D position, Video::Colorf color, float radius, int id)
	{
		irr::scene::ILightSceneNode* l =
			Manager->addLightSceneNode(
			parent ? parent->get_NativeSceneNode() : 0,
			irr::NativeConverter::getNativeVector(position),
			irr::NativeConverter::getNativeColorf(color), radius, id);
		if (!l)
			return 0;
		return new ILightSceneNode(l);
	}

	IBillboardSceneNode* ISceneManager::AddBillboardSceneNode(ISceneNode* parent,
		Core::Dimension2Df size, Core::Vector3D position, int id)
	{
		irr::scene::IBillboardSceneNode* b =
			Manager->addBillboardSceneNode(
			parent ? parent->get_NativeSceneNode() : 0,
			irr::NativeConverter::getNativeDim(size),
			irr::NativeConverter::getNativeVector(position),
			id);
		if (!b)
			return 0;
		return new IBillboardSceneNode(b);
	}

	ISceneNode* ISceneManager::addSkyBoxSceneNode(Video::ITexture* top, Video::ITexture* bottom,
			Video::ITexture* left, Video::ITexture* right, Video::ITexture* front,
			Video::ITexture* back, ISceneNode* parent, int id)
	{
		irr::scene::ISceneNode* n =
			Manager->addSkyBoxSceneNode(
			top ? top->get_NativeTexture() : 0,
			bottom ? bottom->get_NativeTexture() : 0,
			left ? left->get_NativeTexture() : 0,
			right ? right->get_NativeTexture() : 0,
			front ? front->get_NativeTexture() : 0,
			back ? back->get_NativeTexture() : 0,
			parent ? parent->get_NativeSceneNode() : 0,
			id);
		if (!n)
			return 0;
		return new ISceneNode(n);
	}

	ISceneNode* ISceneManager::addEmptySceneNode(ISceneNode* parent, int id)
	{
		irr::scene::ISceneNode* n = 
			Manager->addEmptySceneNode(
				parent ? parent->get_NativeSceneNode() : 0,
				id);
		if (!n)
			return 0;
		return new ISceneNode(n);
	}


}
}