#include "ICameraSceneNode.h"
#include "NativeConverter.h"

namespace Irrlicht
{
namespace Scene
{

	ICameraSceneNode::ICameraSceneNode(irr::scene::ICameraSceneNode* realSceneNode)
		: ISceneNode(realSceneNode)
	{
	}

	ICameraSceneNode::~ICameraSceneNode()
	{
	}

	void ICameraSceneNode::set_ProjectionMatrix(Core::Matrix4 projection)
	{
		getCamSceneNode()->setProjectionMatrix(
			irr::NativeConverter::getNativeMatrix(projection));
	}

	Core::Matrix4 ICameraSceneNode::get_ProjectionMatrix()
	{
		return irr::NativeConverter::getNETMatrix(
			getCamSceneNode()->getProjectionMatrix());
	}

	Core::Matrix4 ICameraSceneNode::get_ViewMatrix()
	{
		return irr::NativeConverter::getNETMatrix(
			getCamSceneNode()->getViewMatrix());
	}

	bool ICameraSceneNode::OnEvent(Event event)
	{
		return getCamSceneNode()->OnEvent(irr::NativeConverter::getNativeEvent(event));
	}

	void ICameraSceneNode::set_Target(Core::Vector3D pos)
	{
		getCamSceneNode()->setTarget(irr::NativeConverter::getNativeVector(pos));
	}

	Core::Vector3D ICameraSceneNode::get_Target()
	{
		return irr::NativeConverter::getNETVector(getCamSceneNode()->getTarget());
	}

	void ICameraSceneNode::set_UpVector(Core::Vector3D pos)
	{
		getCamSceneNode()->setUpVector(irr::NativeConverter::getNativeVector(pos));
	}

	Core::Vector3D ICameraSceneNode::get_UpVector()
	{
		return irr::NativeConverter::getNETVector(getCamSceneNode()->getUpVector());
	}

	float ICameraSceneNode::get_NearValue()
	{
		return getCamSceneNode()->getNearValue();
	}

	void ICameraSceneNode::set_NearValue(float value)
	{
		getCamSceneNode()->setNearValue(value);
	}

	float ICameraSceneNode::get_FarValue()
	{
		return getCamSceneNode()->getFarValue();
	}

	void ICameraSceneNode::set_FarValue(float value)
	{
		getCamSceneNode()->setFarValue(value);
	}

	float ICameraSceneNode::get_AspectRatio()
	{
		return getCamSceneNode()->getFarValue();
	}

	void ICameraSceneNode::set_AspectRatio(float f)
	{
		getCamSceneNode()->setAspectRatio(f);
	}

	float ICameraSceneNode::get_FOV()
	{
		return getCamSceneNode()->getFOV();
	}

	void ICameraSceneNode::set_FOV(float value)
	{
		getCamSceneNode()->setFOV(value);
	}

	ViewFrustrum ICameraSceneNode::get_ViewFrustrum()
	{
		return irr::NativeConverter::getNETFrustrum(
			*getCamSceneNode()->getViewFrustrum());
	}

	void ICameraSceneNode::set_InputReceiverEnabled(bool enabled)
	{
		getCamSceneNode()->setInputReceiverEnabled(enabled);
	}

	bool ICameraSceneNode::get_InputReceiverEnabled()
	{
		return getCamSceneNode()->isInputReceiverEnabled();
	}


}
}