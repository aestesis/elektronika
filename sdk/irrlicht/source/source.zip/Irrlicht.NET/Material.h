// Copyright (C) 2002-2004 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in Irrlicht.h

#pragma once

#include "ITexture.h"
#include "Color.h"

namespace Irrlicht
{
namespace Video
{
	/// <summary>
	/// Abstracted and easy to use standard material modes.
	/// </summary>
	public __value enum MaterialType
	{
		/// Standard solid material. Only first texture is used, which is
		/// supposed to be the diffuse material.
		SOLID = 0,			

		/// Solid material with 2 texture layers. The second is blended onto the
		/// first using the alpha value of the vertex colors.
		/// This material is currently not implemented in OpenGL, but it
		/// works with DirectX.
		SOLID_2_LAYER,

		/// Material type with standard lightmap technique: 
		/// There should be 2 textures: The first texture layer is a diffuse map,
		/// the second is a light map. Vertex light is ignored.
		LIGHTMAP,

		/// Material type with lightmap technique like EMT_LIGHTMAP, but
		/// lightmap and diffuse texture are not modulated, but added instead.
		LIGHTMAP_ADD,

		/// Material type with standard lightmap technique: 
		/// There should be 2 textures: The first texture layer is a diffuse map,
		/// the second is a light map. Vertex light is ignored.
		/// The texture colors are effectively multiplyied by 2 for brightening.
		/// like known in DirectX as D3DTOP_MODULATE2X.
		LIGHTMAP_M2,

		/// Material type with standard lightmap technique: 
		/// There should be 2 textures: The first texture layer is a diffuse map,
		/// the second is a light map. Vertex light is ignored.
		/// The texture colors are effectively multiplyied by 4 for brightening.
		/// like known in DirectX as D3DTOP_MODULATE4X.
		LIGHTMAP_M4,

		/// Like EMT_LIGHTMAP, but also supports dynamic lighting.
		LIGHTMAP_LIGHTING,

		/// Like EMT_LIGHTMAP_M2, but also supports dynamic lighting.
		LIGHTMAP_LIGHTING_M2,

		/// Like EMT_LIGHTMAP_4, but also supports dynamic lighting.
		LIGHTMAP_LIGHTING_M4,

		/// Makes the material look like it was reflection the environment
		/// around it. To make this possible, a texture called 'sphere map'
		/// is used, which must be set as Texture1.
		SPHERE_MAP,

		/// A reflecting material with an 
		/// optional additional non reflecting texture layer. The reflection
		/// map should be set as Texture 1.
		/// Please note that this material type is currently not 100% implemented
		/// in OpenGL. It works in DirectX8.
		REFLECTION_2_LAYER,

		/// A transparent material. Only the first texture is used.
		/// The new color is calculated by simply adding the source color and
		/// the dest color. This means if for example a billboard using a texture with 
		/// black background and a red circle on it is drawed with this material, the
		/// result is that only the red circle will be drawn a little bit transparent,
		/// and everything which was black is 100% transparent and not visible.
		/// This material type is useful for e.g. particle effects.
		TRANSPARENT_ADD_COLOR,

		/// Makes the material transparent based on the texture alpha channel.
		/// Only first texture is used. Please note that this material is currenly
		/// NOT IMPLEMENTED.
		TRANSPARENT_ALPHA_CHANNEL,	

		/// Makes the material transparent based on the vertex alpha value.
		TRANSPARENT_VERTEX_ALPHA,

		/// A transparent reflecting material with an 
		/// optional additional non reflecting texture layer. The reflection
		/// map should be set as Texture 1. The transparency depends on the
		/// alpha value in the vertex colors. A texture which will not reflect
		/// can be set als Texture 2.
		/// Please note that this material type is currently not 100% implemented
		/// in OpenGL. It works in DirectX8.
		TRANSPARENT_REFLECTION_2_LAYER,

		/// This value is not used. It only forces this enumeration to compile in 32 bit. 
		FORCE_32BIT_DO_NOT_USE = 0x7fffffff	
	};

	/// <summary>
	/// Material flags
	/// </summary>
	public __value enum MaterialFlag
	{
		/// Draw as wireframe or filled triangles? Default: false
		WIREFRAME = 0,

		/// Flat or Gouraud shading? Default: true
		GOURAUD_SHADING,

		/// Will this material be lighted? Default: true
		LIGHTING,

		/// Is the ZBuffer enabled? Default: true
		ZBUFFER,

		/// May be written to the zbuffer or is it readonly. Default: true
		/// This flag is ignored, if the material type is a transparent type.
		ZWRITE_ENABLE,

		/// Is backfaceculling enabled? Default: true
		BACK_FACE_CULLING,

		/// Is bilinear filtering enabled? Default: true
		BILINEAR_FILTER,

		/// Is trilinear filtering enabled? Default: false
		/// If the trilinear filter flag is enabled,
		/// the bilinear filtering flag is ignored.
		TRILINEAR_FILTER,

		/// Is fog enabled? Default: false
		FOG_ENABLE,

		/// This is not a flag, but a value indicating how much flags there are.
		MATERIAL_FLAG_COUNT 
	};

	const System::Int32 MATERIAL_MAX_TEXTURES = 2;

	/// <summary>
	/// Class describing material parameters
	///</summary>
	public __value class Material
	{
	public:

		/// default constructor, creates a solid material with standard colors
		Material()
		: AmbientColor(255,255,255,255), DiffuseColor(255,255,255,255),
		EmissiveColor(0,0,0,0), SpecularColor(0,0,0,0), Texture1(0), Texture2(0),
			Type(SOLID), Shininess(0.0f)
		{
			Flags[MaterialFlag::WIREFRAME] = false;
			Flags[MaterialFlag::LIGHTING] = true;
			Flags[MaterialFlag::ZBUFFER] = true;
			Flags[MaterialFlag::ZWRITE_ENABLE] = true;
			Flags[MaterialFlag::BACK_FACE_CULLING] = true;
			Flags[MaterialFlag::GOURAUD_SHADING] = true;
			Flags[MaterialFlag::BILINEAR_FILTER] = true;
			Flags[MaterialFlag::TRILINEAR_FILTER] = false;
			Flags[MaterialFlag::FOG_ENABLE] = false;
		}

		/// <summary>
		/// Type of the material. Specifies how everything is blended together
		/// </summary>
		MaterialType Type;	

		/// <summary>
		/// How much ambient light (a global light) is reflected by this material.
		/// The default is full white, meaning objects are completely globally illuminated.
		/// Reduce this if you want to see diffuse or specular light effects, or change
		/// the blend of colors to make the object have a base color other than white.
		/// </summary>
		Color AmbientColor;		

		/// <summary>
		/// How much diffuse light coming from a light source is reflected by this material.
		/// The default is full white.
		/// </summary>
		Color DiffuseColor;		

		/// <summary>
		/// Light emitted by this material. Default is to emitt no light.
		/// </summary>
		Color EmissiveColor;	

		/// <summary>
		/// How much specular light (highlights from a light) is reflected. 
		/// The default is to reflect no specular light. 
		///</summary>
		Color SpecularColor;	

		/// <summary>
		/// Value affecting the size of specular highlights.
		/// </summary>
		float Shininess;			

		/// </summary>
		/// Primary texture layer.
		/// <summary>
		ITexture* Texture1;

		/// </summary>
		/// Secondary texture layer.
		/// <summary>
		ITexture* Texture2;

		/// <summary>
		/// Determinates if the material is somehow transparent.
		/// Returns true if material is transparent, false if not.
		/// </summary>
		inline bool isTransparent()
		{
			return Type == TRANSPARENT_ADD_COLOR ||
					Type == TRANSPARENT_ALPHA_CHANNEL || 
					Type == TRANSPARENT_VERTEX_ALPHA ||
					Type == TRANSPARENT_REFLECTION_2_LAYER;
		}

		///<summary>
		/// Material flags, can also be set by all the properties of this class
		///</summary>
		bool Flags __nogc [MATERIAL_FLAG_COUNT];


		/// <summary>
		/// Draw as wireframe or filled triangles? Default: false
		/// </summary>
		__property bool get_Wireframe()	{	return Flags[WIREFRAME];	}

		/// <summary>
		/// Flat or Gouraud shading? Default: true
		/// </summary>
		__property bool get_GouraudShading() {	return Flags[GOURAUD_SHADING];	}

		/// <summary>
		/// Will this material be lighted? Default: true
		/// </summary>
		__property bool get_Lighting()	{	return Flags[LIGHTING];	}

		/// <summary>
		/// Is the ZBuffer enabled? Default: true
		/// </summary>
		__property bool get_ZBuffer() {	return Flags[ZBUFFER];	}

		/// <summary>
		/// May be written to the zbuffer or is it readonly. Default: true
		/// This flag is ignored, if the MaterialType is a transparent type.
		/// </summary>
		__property bool get_ZWriteEnable()	{	return Flags[ZWRITE_ENABLE];	}

		/// <summary>
		/// Is backfaceculling enabled? Default: true
		/// </summary>
		__property bool get_BackfaceCulling() {	return Flags[BACK_FACE_CULLING]; }

		/// <summary>
		/// Is bilinear filtering enabled? Default: true
		/// </summary>
		__property bool get_BilinearFilter() {	return Flags[BILINEAR_FILTER];	}

		/// <summary>
		/// Is trilinear filtering enabled? Default: false
		/// If the trilinear filter flag is enabled,
		/// the bilinear filtering flag is ignored.
		/// </summary>
		__property bool get_TrilinearFilter() {	return Flags[TRILINEAR_FILTER];	}

		/// <summary>
		/// Is fog enabled? Default: false
		/// </summary>
		__property bool get_FogEnable() {	return Flags[FOG_ENABLE];	}

		/// <summary>
		/// Draw as wireframe or filled triangles? Default: false
		/// </summary>
		__property void set_Wireframe(bool f)	{	Flags[WIREFRAME] = f;	}

		/// <summary>
		/// Flat or Gouraud shading? Default: true
		/// </summary>
		__property void set_GouraudShading(bool f) {	Flags[GOURAUD_SHADING] = f;	}

		/// <summary>
		/// Will this material be lighted? Default: true
		/// </summary>
		__property void set_Lighting(bool f)	{	Flags[LIGHTING] = f;	}

		/// <summary>
		/// Is the ZBuffer enabled? Default: true
		/// </summary>
		__property void set_ZBuffer(bool f) {	Flags[ZBUFFER] = f;	}

		/// <summary>
		/// May be written to the zbuffer or is it readonly. Default: true
		/// This flag is ignored, if the MaterialType is a transparent type.
		/// </summary>
		__property void set_ZWriteEnable(bool f)	{	Flags[ZWRITE_ENABLE] = f;	}

		/// <summary>
		/// Is backfaceculling enabled? Default: true
		/// </summary>
		__property void set_BackfaceCulling(bool f) {	Flags[BACK_FACE_CULLING] = f; }

		/// <summary>
		/// Is bilinear filtering enabled? Default: true
		/// </summary>
		__property void set_BilinearFilter(bool f) {	Flags[BILINEAR_FILTER] = f;	}

		/// <summary>
		/// Is trilinear filtering enabled? Default: false
		/// If the trilinear filter flag is enabled,
		/// the bilinear filtering flag is ignored.
		/// </summary>
		__property void set_TrilinearFilter(bool f) {	Flags[TRILINEAR_FILTER] = f;	}

		/// <summary>
		/// Is fog enabled? Default: false
		/// </summary>
		__property void set_FogEnable(bool f) {	Flags[FOG_ENABLE] = f;	}


	};

} // end namespace video
} // end namespace irr
