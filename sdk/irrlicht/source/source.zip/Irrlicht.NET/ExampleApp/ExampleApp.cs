using System;
using Irrlicht;
using Irrlicht.Video;
using Irrlicht.Core;
using Irrlicht.Scene;

	/// <summary>
	/// Example application using Irrlicht.NET 
	/// Some simple rotating primitives are drawn without using the scene manager
	/// </summary>
	class ExampleApp
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			IrrlichtDevice device = new IrrlichtDevice(DriverType.DIRECTX8);

			device.ResizeAble = true;
			device.WindowCaption = "Irrlicht.NET test";

			// load some textures and meshes

			ITexture texSydney = device.VideoDriver.GetTexture(@"..\..\media\sydney.bmp");
			ITexture texWall = device.VideoDriver.GetTexture(@"..\..\media\wall.jpg");
			ITexture texLogo = device.VideoDriver.GetTexture(@"..\..\media\irrlichtlogoaligned.jpg");
			Irrlicht.Scene.IAnimatedMesh mesh = 
				device.SceneManager.GetMesh(@"..\..\media\sydney.md2");

			if (mesh == null)
			{
				System.Windows.Forms.MessageBox.Show(
					@"Could not load mesh ..\..\media\sydney.md2, exiting.",
					"Problem starting program");
				return;
			}

			// set up the scene			

			ICameraSceneNode cam = 
				device.SceneManager.AddCameraSceneNodeFPS(null, 100, 100, -1);
			cam.Position = new Vector3D(20,0,-50);

			ISceneNode node = device.SceneManager.AddTestSceneNode(15,
				null, -1, new Vector3D(30,-15,0));
			node.SetMaterialTexture(0, texWall);

			node = device.SceneManager.AddAnimatedMeshSceneNode(mesh, null, -1);
			node.SetMaterialTexture(0, texSydney);
			node.SetMaterialFlag(MaterialFlag.LIGHTING, false);

			// start drawing loop

			int fps = 0;

			while(device.Run())
				if (device.WindowActive)
				{
					device.VideoDriver.BeginScene(true, true, new Color(255,0,0,50));

					device.SceneManager.DrawAll();
					
					device.VideoDriver.Draw2DImage(
						texLogo, new Position2D(10,10),
						new Rect(0,0,88,31), 
						new Rect(new Position2D(0,0),device.VideoDriver.ScreenSize),
						new Color(0xffffff), false);

					device.VideoDriver.EndScene();

					if (fps != device.VideoDriver.FPS)
					{
						fps = device.VideoDriver.FPS;
						device.WindowCaption = "Irrlicht.NET test (primitives:" + 
							device.VideoDriver.PrimitiveCountDrawn + ") fps:" + fps;
					}
				}
		}
	}
