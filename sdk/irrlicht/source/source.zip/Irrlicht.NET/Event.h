// Copyright (C) 2002-2004 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in Irrlicht.h

#pragma once

#using <mscorlib.dll>
using namespace System;


namespace Irrlicht
{

	/// <summary>
	/// An enum for all event types
	/// </summary>
	__value public enum EventType
	{
		//! An event of the graphical user interface.
		GUI_EVENT = 0,

		//! A mouse input event.
		MOUSE_INPUT_EVENT,

		//! A key input evant.
		KEY_INPUT_EVENT,

		//! A log event
		LOG_TEXT_EVENT
	};


	/// <summary>
	/// Struct for holding event data. An event can be a gui, mouse or keyboard event.
	/// </summary>
	public __value class Event
	{
	public:
		__property EventType get_Type() { return type; }

	protected:

		EventType type;
	};

}